 #
# Copyright 2017 Matthew Langley. All rights reserved.
#


"""
Simulation of Boolean networks
"""

import argparse
import boolean2 as bn
import itertools as it
import multiprocessing as mp
#it is not working in python 3:
#import multiprocessing.forking as forking
#insteade I use this as a test:
import multiprocessing.popen_fork as forking
import os
import re
import sys
import time


#______________________________FUNCTION DEFINITIONS____________________________________________

flow_cell_to_environment={}
flow_environment_to_cell={}
flag_flow_info_cell_to_environment= False
flag_flow_info_environment_to_cell= False


# calculate the run time:
start_time = time.time()
def fix_multiprocessing_for_exe():
    """
    Code snippet to make multiprocessing work properly on Windows when frozen
    into a .exe using pyinstaller.
    [1] https://github.com/pyinstaller/pyinstaller/wiki/Recipe-Multiprocessing
    """
    mp.freeze_support()
    if sys.platform.startswith('win'):
        # First define a modified version of Popen.
        class _Popen(forking.Popen):
            def __init__(self, *args, **kw):
                if hasattr(sys, 'frozen'):
                    # We have to set original _MEIPASS2 value from sys._MEIPASS
                    # to get --onefile mode working.
                    os.putenv('_MEIPASS2', sys._MEIPASS)
                try:
                    super(_Popen, self).__init__(*args, **kw)
                finally:
                    if hasattr(sys, 'frozen'):
                        # On some platforms (e.g. AIX) 'os.unsetenv()' is not
                        # available. In those cases we cannot delete the variable
                        # but only set it to the empty string. The bootloader
                        # can handle this case.
                        if hasattr(os, 'unsetenv'):
                            os.unsetenv('_MEIPASS2')
                        else:
                            os.putenv('_MEIPASS2', '')

        # Second override 'Popen' class with our modified version.
        forking.Popen = _Popen



def Parser_function():
        # Configure command line arguments
    parser = argparse.ArgumentParser(description='Simulate a Boolean network.',
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('rules',
                        help='File describing the Boolean network to be simulated')
    parser.add_argument('initials',
                        help='File describing initial state of all elements in network')
    parser.add_argument('cellinteractions_address',
                        help='File describing the interactions between the cells')

    parser.add_argument('parameters',
                        nargs='?',
                        help='(optional) File containing simulation parameters described below')
    parser.add_argument('--output',
                        help='Output file destination')
    parser.add_argument('--ncell',
                        type=int,
                        default=1,
                        help='number of cells in the colony')
    parser.add_argument('--runs',
                        dest='runs',
                        type=int,
                        default=1000,
                        help='Number of simulation runs to perform')
    parser.add_argument('--steps',
                        dest='steps',
                        type=int,
                        default=100,
                        help='Number of Boolean update steps per simulation')
    parser.add_argument('--processes',
                        dest='nprocesses',
                        type=int,
                        default=1,
                        help='Number of processes for parallel computation')
    modeGroup = parser.add_mutually_exclusive_group()
    modeGroup.add_argument('--sync',
                           dest='mode',
                           action='store_const',
                           const='sync',
                           help='All genes are updated at each step')
    modeGroup.add_argument('--async',
                           dest='mode',
                           action='store_const',
                           const='async',
                           help='Random subset of genes updated at each step')
    parser.add_argument('--writeStateDict',
                         dest='writeStateDict',
                         action='store_true',
                         default=False,
                         help='Write resulting state dictionary to file')
    parser.add_argument('--writeEdgeDict',
                         dest='writeEdgeDict',
                         action='store_true',
                         default=False,
                         help='Write resulting edge dictionary to file')

    # Switch between listening to command-line arguments or hard-coded
    # arguments depending on whether running in IDE or from cmd.
    if any([name.startswith('SPYDER') for name in os.environ]):
        myArgs = 'input/boolean-psc-jun2017-boolean-functions.txt  input/boolean-psc-jun2017-initial-conditions-2i-L+B-A.txt    input/boolean-psc_no_interactions.txt  --output output_run/output.gml --ncell 1 --runs 100  --steps 200  --processes 3 --async  '
        args = parser.parse_args(myArgs.split())
    else:
        args = parser.parse_args()

    # If a parameter file is specified, read in parameters from there.
    if args.parameters is not None:
        args = read_parameters(args, args.parameters)

    # Default to asyncrhonous simulation mode.
    if args.mode is None:
        args.mode = 'async'

    # Make sure the specified model file actually exists.
    if not os.path.isfile(args.rules):
        parser.error('The specified model file does not exist: %s' %(args.rules))
    elif not os.path.isfile(args.initials):
        parser.error('The specified model file does not exist: %s' %(args.initials))

    # Read in the cells files and concatenate them.
    initialsText = ''
    with open(args.initials, 'r') as f:
        initialsText = f.read()
    rulesText = ''
    with open(args.rules, 'r') as f:
        rulesText = f.read()
    args.model = initialsText + '\n' + rulesText

    #Read the environment file
    environmentText=''
    with open(args.cellinteractions_address, 'r') as f:
        environmentText=f.read()
    args.cellinteractions = environmentText

    return args




def read_parameters(args, paramFile):
    """
    Reads command line arguments specifiying parameters for Boolean simulation
    from a specified file

    Args:
        args (argparse.Namespace)
            Current arguments object from argparse
        paramFile (str)
            Filepath to parameters file

    Returns:
        (argparse.Namespace)
            Updated arguments object, with arguments added as specified in
            paramFile
    """

    with open(paramFile, 'r') as f:
        for line in f:
            # Ignore any comments and blank lines
            if len(line.strip()) > 0 and (not line.startswith('#')):
                param, value = [x.strip() for x in line.split('=')]
                if param == 'runs':
                    args.runs = int(value)
                elif param == 'steps':
                    args.steps = int(value)
                elif param == 'mode':
                    if value == 'sync':
                        args.mode = 'sync'
                    else:
                        args.mode = 'async'
                elif param == 'processes':
                    args.nprocesses = int(value)
                elif param == 'writeStateDict':
                    if value in ['True', 'true', 'T', 't', '1', 'Yes', 'Y', 'y']:
                        args.writeStateDict = True
                    else:
                        args.writeStateDict = False
                elif param == 'writeEdgeDict':
                    if value in ['True', 'true', 'T', 't', '1', 'Yes', 'Y', 'y']:
                        args.writeEdgeDict = True
                    else:
                        args.writeEdgeDict = False

    return args


def simulate_one_run(modelText, mode, steps,ncell):
    global flag_flow_info_cell_to_environment
    global flow_cell_to_environment
    global flag_flow_info_environment_to_cell
    global flow_environment_to_cell
    """
    Simulates a single run instance of a Boolean model, i.e. only one
    trajectory from one initial condition. The simulation consists of a
    specified number of discrete time steps in which some (async) or all
    (sync) of the genes in the model are updated based on their associated
    Boolean update function.

    Args:
        modelText (str)
            The Boolean model to simulate, either as a filepath or the
            complete definition as text.
        mode (str)
            The update strategy used for simulation. Either 'async' or 'sync'.
            Defaults to 'async'.
        steps (int)
            The number of update time steps performed in each run. Defaults to
            100.
        ncell
            The number of cells in the colony

    Returns:
        (list)
            The trajectory of Boolean states traversed by the simulation, up
            to the specified number of steps or the end of any limit cycle
            that was encountered.

    ....... TO BE WRITTEN
    """
    #___________________________________
    # create and initialize cells
    cells = []
    for i in range(ncell):
        #modelText.format(i+1) : gives each gene the index i for example: BMP -> BMP_10 , it means BMP in cell #10
        cells.append(bn.Model( text=modelText.format(i+1), mode=mode))

    for i in range(ncell):
        cells[i].initialize()
        cells[i].parser.RULE_SETVALUE=set_value_cells

    # create and initialize environment
    environment=bn.Model( text=args.cellinteractions, mode=mode)
    environment.initialize()
    environment.parser.RULE_SETVALUE = set_value_environment


    # iterate for #steps  times the cell objects
    #pay attention to the range=[1,steps+1]
    for iteration in range (1,steps+1):

        #1-update each cell for one step
        for i in range(ncell):
            cells[i].iterate(1)



        #2- update states of the environmen due to states of the cells:
        #update the global dictionary 'flow_cell_to_environment' with current with the desigred modified state
        flow_cell_to_environment=cell_to_environment (ncell,cells,environment,iteration)
        #replace the environment state:
        '''
        ##Warning:this part is because the weekness of BooleanNet in handeling set_value
        only after at least 1 iteration. Later by modifiying the BooleanNet package this should be
        perforemd more naturally.
        Here the environment is iterated for 1 step, then the desigred state is replaced with the resultant
        state after the iteration. and finally the state before iteration is deleted:
        '''
        #print (iteration)
        #print(environment.states)
        flag_flow_info_cell_to_environment= True
        environment.iterate(1)
        flag_flow_info_cell_to_environment=False
        #note that environment is not updated yet=> 'iteration-1'
        del environment.states[iteration-1]


        #3-update environment one step
        environment.iterate(1)

        #4-update states of the cells  due to states of the environment:
        flow_environment_to_cell=environment_to_cell(ncell,cells,environment,iteration)
        '''
        ##Warning:this part is because the weekness of BooleanNet in handeling set_value
        only after at least 1 iteration. Later by modifiying the BooleanNet package this should be
        perforemd more naturally.
        Here the environment is iterated for 1 step, then the desigred state is replaced with the resultant
        state after the iteration. and finally the state before iteration is deleted:
        '''
        flag_flow_info_environment_to_cell=True
        for i in range(ncell):
            cells[i].iterate(1)
            del cells[i].states[iteration]
        flag_flow_info_environment_to_cell=False
    '''
    Determine length of path to return based on limit cycle detection.
    Need to return (index + size + 1) instead of (index + size) so that the
    returning edge from the last state in cycle to the first one is included
    in the edge list:
    !!!!WARNING!!!!
    This part is disabled due to this fact:
        --- cycles are no more valid because the system is now an open system and can come
        out from
    '''
    #index, size = model.detect_cycles()
    #if index + size == 0 or index + size >= steps:
    #    pathLen = steps
    #else:
    #    pathLen = index + size + 1

    #wrapup the results:
    single_run_results=[]
    single_run_results.append(environment.states)
    for i in range(ncell):
        single_run_results.append(cells[i].states)

    return single_run_results


def simulate(args,modelText, steps, runs,mode='async', nprocesses=None):
    """
    Simulates a Boolean model over multiple instances. Each instance (or run)
    consists of a specified number of discrete time steps in which some
    (async) or all (sync) of the genes in the model are updated based on their
    associated Boolean update function. Since these Boolean simulations can be
    time-intensive, the method allows for run instances to be performed on
    parallel processes.

    Args:
        modelText (str)
            The Boolean model to simulate, either as a filepath or the
            complete definition as text.
        mode (str)
            The update strategy used for simulation. Either 'async' or 'sync'.
            Defaults to 'async'.
        steps (int)
            The number of update time steps performed in each run. Defaults to
            100.
        runs (int)
            The number of run instances to simulate. Defaults to 100.
        nprocesses (int)
            The number of processes used for the parallel worker pool. Set to
            1 to run without multiprocessing. If unspecifed, the number of
            worker processes used will be equal to the number of CPU cores on
            the target machine.

    Returns:
        (list)
            A list of all of trajectories produced in the batch of simulation
            instances. Each trajectory in the list is itself a list of the
            Boolean states traversed by that run instance of the simulation,
            up to the specified number of steps or the end of any limit cycle
            that was encountered.
    """


    # If nprocesses not specified, set to the number of CPU cores on target
    # machine.
    if nprocesses is None:
        nprocesses = mp.cpu_count()


    # Run the simulations by calling into 'simulate_one_run' and retrieve the
    # results. If mulitple processes are to be used, set up a multiprocessing
    # Pool of workers to perform the simulations.
    modelText_=args.model
    mode_=args.mode
    steps_=args.steps
    ncell_=args.ncell
    if nprocesses > 1:
        pool = mp.Pool(processes=nprocesses)
        handles = [pool.apply_async(simulate_one_run,args=
                                    (modelText_, mode_, steps_,ncell_)) for i in range(runs)]
        pool.close()
        results = [r.get() for r in handles]
    else:
        results = [ simulate_one_run(modelText_, mode_, steps_,ncell_)  for i in range(runs)]
    # Return the list of boolean2.state.State trajectories traversed by each  run instance.

    return results


# create a custom value setter for cells
def set_value_cells( state, name, value, p ):
    "Custom value setter: update the envirements state due to cell state"
    # if this is a share node that its state should be updated, update value to the cell outputs
    if flag_flow_info_environment_to_cell== True:
        if name in flow_environment_to_cell:
            value =flow_environment_to_cell[name]
        else:
            print('Warning: One member of cells is not copied at Set_value function',name)
    #print(flag_flow_cell_to_environment)
    #sets the attribute of the node
    setattr( state, name, value )
    return value

# create a custom value setter for environment
def set_value_environment( state, name, value, p ):
    "Custom value setter: update the envirements state due to cell state"
    # if this is a share node that its state should be updated, update value to the cell outputs
    if flag_flow_info_cell_to_environment== True:
        if name in flow_cell_to_environment:
            value =flow_cell_to_environment[name]
        else:
            print('Warning: One member of environment is not copied at Set_value function',name)
    #print(flag_flow_cell_to_environment)
    #sets the attribute of the node
    setattr( state, name, value )
    return value

def cell_to_environment (ncell,cells,environment,iteration):
    '''
    inforation flow from cells to environment:
    This function first obtains the current state of the environment and makes a dictionary
    from it to use it to update environment state due to the cell states.
    Then replace in the dictionary the states of the shared nodes with the values of their cells
    counterparts.
    '''
    flow={}
    #get the current state of environment(note that environment is not updated yet=> 'iteration-1'):
    current_state=environment.states[iteration-1]
    for j in current_state:
        flow.update ( { str(j) : environment.states[iteration-1][j] } )
    # for each cell, the state of nodes that are shared with environment are obtained:
    # then the dictionary, flow will be updated
    for i in range(ncell):
        # now only the state of those nodes that are shared with environment are captured
        for j in environment.nodes:
            if j in cells[i].nodes:
                # states of shared node for the current iteration is stored here:
                flow.update ({str(j) : cells[i].states[iteration][j]})
    return flow

def environment_to_cell(ncell,cells,environment,iteration):
    '''
    inforation flow from environment to cells :
    This function first obtains the current state of the cells and makes a dictionary
    from them to use it to update cells states due to the environment states.
    Then replace in the dictionary the states of the shared nodes with the values of their environment
    counterparts.
    '''
    flow={}
    for i in range(ncell):
        #get the current state of cells:(note that cells are already updated => index='iteration')
        current_state=cells[i].states[iteration]
        for j in current_state:
            flow.update ({ j : cells[i].states[iteration][j] })
    # now update the 'flow' due to the environment states
    for i in range(ncell):
        # now only the state of those nodes that are shared with environment are captured
        for j in environment.nodes:
            if j in cells[i].states[iteration]:
                flow.update ( {j :environment.states[iteration][j] } )
    return flow



def assign_ids(stateList):
    """
    Given a list of Boolean State objects from a simulation, assigns a
    globally consistent fingerprint to that State object as a new attribute,
    'id'. This is necessary because we can't trust how BooleanNet handles
    state.fp() when using multiprocessing, since it relies on global variables
    for the State class that are not shared across processes.

    Args:
        stateList (list)
            A list of all Boolean states to which IDs should be assigned.
            States with the same binary profile will be assigned identical IDs.
    """

    # We can't trust how BooleanNet handles state.fp() when using
    # multiprocessing, since it relies on global variables for the State class
    # that are not shared across processes. Therefore, we need to implement
    # our own version of fingerprinting that is calculated after all simulation
    # runs have completed.
    # stateDict = {s.fp(): s for s in stateList}

    myMapper = {}
    myCounter = 0
    for state in stateList:
        # Use hashed value of string representation of State for indexing in
        # the dictionary. Need to do this instead of the State object itself
        # because even if two State objects represent the same binary profile,
        # they are still different *objects*.
        # i.e. Even if stateA.bin() == stateB.bin();
        #      myMapper[stateA] != myMapper[stateB]
        key = hash(str(state))
        if key not in myMapper:
            myMapper[key] = myCounter
            myCounter += 1
        state.id = myMapper[key]


def assign_belongs_to(*trajectories,runs,ncell):
    """
    Given a list of Boolean State objects from a simulation, assigns a
    belonging to them, it means that each state is for environment? or for a cell? if yes which cell
    the results is in this way:
        belonging=0  : environment
        belonging=1  : cell #1
        belonging=2  : cell #2 (if exists)
        etc..

    Args:
        stateList (list)
            A list of all Boolean states to which IDs should be assigned.
            States with the same binary profile will be assigned identical IDs.
    """
    for i in range (runs):
        for j in range (ncell+1):
            # trajectories[i][j] will be the trajectory of the i_th run of the J_th item ()
            # j=0: environment , j=1 cell #1, j=2 cell #2 etc
            for states in trajectories[i][j]:
                states .belongs_to=j
#                print(states)
#                print('\n')
#


def make_state_dictionary(stateList):
    """
    Given a list of Boolean states, returns a dictionary in which the keys are
    an ID (fingerprint) unique to that state, and the associated values are
    the Boolean state. Note that IDs for a state are consistent across runs
    completed at the same time; i.e. '101' in run #1 and '101' in run #2 will
    have the same ID. However, consistent IDs are not guaranteed across
    experiments; i.e. if I run a model today, and that same model tomorrow (new
    instance of Python), the IDs will be different.

    Args:
        stateList (list)
            A list of Boolean states to include in the dictionary.

    Returns:
        (dict)
            A dictionary in which the keys are an ID (fingerprint) unique to
            that state, and the associated values are the Boolean state.
    """

    # We can't trust how BooleanNet handles state.fp() when using
    # multiprocessing, since it relies on global variables for the State class
    # that are not shared across processes. Therefore, we must use our own
    # State.id attribute which is created after all simulations are completed
    # and control returns to the main (parent) process.

    stateDict = {s.id: s for s in stateList}
    return stateDict

def make_edge_dictionary(trajectoryList):
    """
    Given a list of Boolean state trajectories, returns a dictionary in which
    the keys are a tuple of (sourceID, targetID) for each edge in the
    trajectories, and the values are the (number of times that edge was
    encountered in the trajectory list, the belongs_to of the edge)

    Args:
        trajectoryList (list)
            A list of Boolean state trajectories.

    Returns:
        (dict)
            A dictionary in which the keys are a tuple of (sourceID, targetID)
            for each edge in the trajectories, and the values are the number
            of times that edge was encountered in the trajectory list.
    """

    edgeDict = {}
    for trajectory in trajectoryList:
        for source, target in zip(trajectory, trajectory[1:]):
            s = source.id
            t = target.id
            if (s,t) in edgeDict.keys():
                edgeDict[(s,t)] = ( edgeDict[(s,t)][0]+1, source.belongs_to )
            else:
                edgeDict[(s,t)]= ( 1, source.belongs_to )
    return edgeDict



def write_gml(stateDict, edgeDict, edgeDictFile,ncell):
    """
    Writes the results of the simulation (i.e. the directed graph representing
    the simulation's state transition graph) to file in the Graph Modeling
    Language, GML. Details of the GML format available at:
    [1] http://www.fim.uni-passau.de/fileadmin/files/lehrstuhl/brandenburg/projekte/gml/gml-technical-report.pdf
    [2] https://en.wikipedia.org/wiki/Graph_Modelling_Language

    Note: Due to limitations of the GML spec, any non alpha-numeric characters
    will be ommitted from the gene names

    Args:
        stateDict (dict)
            The state dictionary for the simulation
        edgeDict (dict)
            The edge dictionary for the simulation
        outputFile (str)
            The destination filepath
    """
    """
    For each component ie environment and each cell creates a seprate .gml file
    with the general name of  outpu_ + str(belongs_to)
    """
    # for each element open new file: range (ncell+1) : ncell plus environment
    for n in range (ncell+1):
        # creating the name of the output
        if '\\' in args.rules:
            args.rules = args.rules.replace('\\', '/')
        if '/' in args.rules:
            graphName = args.rules.rsplit('/', 1)[1].rsplit('.', 1)[0]
        else:
            graphName = args.rules.rsplit('.', 1)[0]
        if args.output is None:
            args.output = 'Output/' + graphName + '_output.gml'
        outputFile=args.output +'_'+str(n)

        # find unique genes. Importantly the way we treat is: A_1 != A_2
        genes= [sorted(list(stateDict.values())[i].keys())  for i in range ( len(stateDict) )]
        genes=list(it.chain(*genes))
        genes=set(genes)
        genes.remove('id')
        genes.remove('belongs_to')
        genes=sorted(genes)

        lines = []
        lines.append('graph [')
        lines.append('        directed 1')
        lines.append('        name "%s"' %(graphName))
        for k,v in stateDict.items():
            if v.belongs_to == n:
                lines.append('        node [')
                lines.append('               id %i' %(k))
                lines.append('               label "%i"' %(k))
                #print(k, ' v= ', v)
                for gene in genes:
                    #gene0 = re.sub(r'[^A-Za-z0-9#]+', "", gene)
                    ## !!!!  might cause problems late??? to replace gene0 with gene?
                    gene0=gene

                    if gene in  v :

                        lines.append('               %s %i' %(gene0, int(v[gene])))
                lines.append('        ]')


        for (s,t), (f, belongs) in edgeDict.items():
             if belongs == n:
                lines.append('        edge [')
                lines.append('               source %i' %(s))
                lines.append('               target %i' %(t))
                lines.append('               weight %i' %(f))
                lines.append('        ]')
        lines.append(']')
        with open(outputFile, 'w') as f:
            f.write('\n'.join(lines))



if __name__ == '__main__':
     #Code runs only if module is executed as mainline. Supports command line arguments.
    # Configure multiprocessing to work properly in frozen .exe version
    fix_multiprocessing_for_exe()
    #parse in the configuration and parameters of the simulation:
    args=Parser_function()


    # Simulate the Boolean network:
    # trajectories[#run][0=environment  <0=cells]
    trajectories = simulate(args,modelText=args.model,
                            steps=args.steps,
                            runs=args.runs,
                            mode=args.mode,
                            nprocesses=args.nprocesses)

    # Aggregate the results of all the runs into dictionaries, ensuring that
    # expression states that are common between runs are given the same ID,
    # and that all the edges that are common between runs are counted.
    assign_ids( list(it.chain( * list(it.chain(*trajectories)) ) ) )

    assign_belongs_to(*trajectories,runs=args.runs,ncell=args.ncell)

    stateDict = make_state_dictionary ( list(it.chain( * list(it.chain(*trajectories)) ) ) )

    edgeDict = make_edge_dictionary(list(it.chain(*trajectories)))

    # Write the results (state transition graph) to file.
    write_gml(stateDict, edgeDict, args.output,ncell=args.ncell)

    print("Run time : %s s " % (time.time() - start_time))
